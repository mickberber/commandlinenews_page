#!/usr/bin/python
from HTMLParser import HTMLParser

import utils

class GUARDIANAHTMLParser(HTMLParser):
    def handle_starttag(self, tag, attrs):
