#!/usr/bin/python
import sys
import os

import utils

from HTMLParser import HTMLParser


def cnn_tests():
    return

def hn_tests():
    return

def main():
    return

if __name__ == '__main__':
    main()
