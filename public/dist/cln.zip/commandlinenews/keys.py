wu_key = 'c12135d4000c56c6'

PATH = '/Users/michaelberber/sideProjects/commandlinenews/services'
