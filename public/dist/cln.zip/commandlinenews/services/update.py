#!/usr/bin/python
import sys

def main():
    return
    
if __name__ == '__main__':
    main()
